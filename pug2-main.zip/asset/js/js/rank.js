/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client/js/rank.js":
/*!*******************************!*\
  !*** ./src/client/js/rank.js ***!
  \*******************************/
/***/ (() => {

eval("const selected = document.querySelector(\"#rank-select\");\nconst rankContainer = document.querySelector(\".rank_container\");\nconst fakeDocument = document.createDocumentFragment();\nfunction paintNotice(rank) {\n  rankContainer.innerText = \"\";\n  for (let i = 0; i < rank.length; i++) {\n    const li = document.createElement(\"li\");\n    const img = document.createElement(\"img\");\n    const title = document.createElement(\"a\");\n    const metaText = document.createElement(\"small\");\n    const br = document.createElement(\"br\");\n    img.src = `${rank[i].resulturl}`;\n    img.style.width = \"331px\";\n    img.style.height = \"206px\";\n    title.href = `/installer/${rank[i]._id}`;\n    title.innerText = `\n    ${rank[i].title}\n    `;\n    metaText.innerText = `추천 ${rank[i].meta.like} · 조회 ${rank[i].meta.view}`;\n    li.appendChild(img);\n    li.appendChild(br);\n    li.appendChild(title);\n    li.appendChild(metaText);\n    fakeDocument.append(li);\n  }\n  rankContainer.append(fakeDocument);\n}\nasync function handleSelected() {\n  const value = selected.options[selected.selectedIndex].value;\n  const response = await fetch(`/api/installer/rank/filter`, {\n    method: \"POST\",\n    headers: {\n      \"Content-Type\": \"application/json\"\n    },\n    body: JSON.stringify({\n      value\n    })\n  });\n  if (response.status === 301) {\n    const rankContainer = await response.json();\n    paintNotice(rankContainer.rank);\n  } else {\n    return;\n  }\n}\nfunction init() {\n  selected.addEventListener(\"input\", handleSelected);\n}\ninit();\n\n//# sourceURL=webpack://installer/./src/client/js/rank.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/client/js/rank.js"]();
/******/ 	
/******/ })()
;