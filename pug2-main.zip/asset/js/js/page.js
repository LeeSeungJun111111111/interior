/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client/js/page.js":
/*!*******************************!*\
  !*** ./src/client/js/page.js ***!
  \*******************************/
/***/ (() => {

eval("const fakeDocument = document.createDocumentFragment();\nconst pageContainer = document.querySelector(\".page__cotainer\");\nconst noticeContainer = document.querySelector(\".notice_container\");\nconst baseCount = 10;\nfunction paintNotice(notice) {\n  noticeContainer.innerText = \"\";\n  for (let i = 0; i < notice.length; i++) {\n    const div = document.createElement(\"div\");\n    const id = document.createElement(\"div\");\n    const title = document.createElement(\"div\");\n    const titlea = document.createElement(\"a\");\n    const view = document.createElement(\"div\");\n    const date = document.createElement(\"div\");\n    div.className = 'item';\n    id.classList.add(\"id\");\n    id.innerText = i;\n    title.classList.add(\"title\");\n    titlea.href = `/notice/${notice[i]._id}`;\n    titlea.innerText = `${notice[i].title}`;\n    view.classList.add(\"view\");\n    view.innerText = `${notice[i].meta.views}`;\n    date.classList.add(\"date\");\n    date.innerText = `${notice[i].createAt}`;\n    div.appendChild(id);\n    div.appendChild(title);\n    title.appendChild(titlea);\n    div.appendChild(view);\n    div.appendChild(date);\n    fakeDocument.append(div);\n  }\n  noticeContainer.appendChild(fakeDocument);\n}\nasync function handlePageContainerClick(e) {\n  const target = e.target.innerText.slice(0, 1);\n  const response = await (await fetch(`/api/notice/page`, {\n    method: \"POST\",\n    headers: {\n      \"Content-Type\": \"application/json\"\n    },\n    body: JSON.stringify({\n      target,\n      baseCount\n    })\n  })).json();\n  paintNotice(response.targetNotice);\n}\nfunction paintCount(totalCount) {\n  for (let i = 1; i <= totalCount; i++) {\n    const a = document.createElement(\"a\");\n    a.style.cursor = \"pointer\";\n    a.innerText = `${i >= totalCount ? `${i}` : `${i}|`}`;\n    fakeDocument.appendChild(a);\n  }\n  pageContainer.appendChild(fakeDocument);\n}\nasync function getNotice() {\n  const response = await (await fetch(`/api/notice/page`, {\n    method: \"POST\",\n    headers: {\n      \"Content-Type\": \"application/json\"\n    },\n    body: JSON.stringify({\n      target: \"1\",\n      baseCount\n    })\n  })).json();\n  paintNotice(response.targetNotice);\n}\nasync function getTotalCount() {\n  const response = await (await fetch(\"/api/notice/count\", {\n    method: \"POST\",\n    headers: {\n      \"Content-Type\": \"application/json\"\n    },\n    body: JSON.stringify({\n      baseCount\n    })\n  })).json();\n  if (response) {\n    const totalCount = Math.ceil(response);\n    paintCount(totalCount);\n  } else {\n    return;\n  }\n}\nfunction init() {\n  getTotalCount();\n  getNotice();\n  pageContainer.addEventListener(\"click\", handlePageContainerClick);\n}\ninit();\n\n//# sourceURL=webpack://installer/./src/client/js/page.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/client/js/page.js"]();
/******/ 	
/******/ })()
;