/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client/js/calculator.js":
/*!*************************************!*\
  !*** ./src/client/js/calculator.js ***!
  \*************************************/
/***/ (() => {

eval("const $steps = document.getElementById('steps');\nconst $display = document.getElementById('display');\nconst $area_btn = document.getElementById('area-btn');\nconst data = {\n  prev: '',\n  curr: '',\n  operator: undefined,\n  pressedResult: false\n};\n$area_btn.addEventListener('click', e => {\n  const target = e.target;\n  if (target.tagName !== 'BUTTON') {\n    return;\n  }\n\n  //리셋\n  if (target.id == \"reset\") {\n    reset_data();\n    return;\n  }\n\n  //숫자\n  if (target.classList.contains('num')) {\n    on_num(data.operator, target);\n  }\n\n  //연산자\n  if (target.classList.contains('op')) {\n    on_ops(target);\n  }\n\n  //=\n  if (target.id == 'btn_result') {\n    show_result();\n  }\n  target.blur();\n});\n\n/*숫자버튼*/\nfunction on_num(bool, target) {\n  const val = target.dataset.val;\n  const prevOrcurr = bool ? 'curr' : 'prev';\n  if (val == \"-1\") {\n    data[prevOrcurr] = String(Number(data[prevOrcurr]) * -1);\n  } else {\n    data[prevOrcurr] += val;\n  }\n  $display.textContent = data[prevOrcurr];\n}\n\n/*연산자*/\nfunction on_ops(target) {\n  $steps.classList.remove('off');\n  const val_op = target.dataset.val;\n  data.operator = val_op;\n  if (data.prev == undefined) {\n    return;\n  }\n  if (!data.pressedResult && data.curr) {\n    show_result();\n  }\n  show_middleStep();\n  data.curr = '';\n  data.pressedResult = false;\n}\n\n/*=*/\nfunction show_result() {\n  if (data.prev == undefined || data.curr == undefined || !data.operator) {\n    return;\n  }\n  data.pressedResult = true;\n  show_finalStep();\n  data.prev = caculSwitch();\n  $display.textContent = data.prev;\n} //show_result\n\nfunction caculSwitch() {\n  const {\n    prev,\n    curr,\n    operator\n  } = data;\n  switch (operator) {\n    case \"+\":\n      return Number(prev) + Number(curr);\n    case \"-\":\n      return Number(prev) - Number(curr);\n    case \"*\":\n      return Number(prev) * Number(curr);\n    case \"/\":\n      return Number(prev) / Number(curr);\n  }\n}\nfunction operator_to_string() {\n  const {\n    operator\n  } = data;\n  switch (operator) {\n    case \"+\":\n      return \"+\";\n    case \"-\":\n      return \"-\";\n    case \"*\":\n      return \"×\";\n    case \"/\":\n      return \"÷\";\n  }\n}\nfunction show_middleStep() {\n  const step_str = `${data.prev} ${operator_to_string()}`;\n  $steps.textContent = step_str;\n}\nfunction show_finalStep() {\n  const cacul_str = `${data.prev} ${operator_to_string()} ${data.curr}`;\n  $steps.textContent = `${cacul_str} =`;\n}\n\n/*리셋*/\nfunction reset_data() {\n  data.prev = '';\n  data.curr = '';\n  $steps.textContent = '&nbsp';\n  $steps.classList.add('off');\n  $display.textContent = '0';\n  data.operator = undefined;\n  data.pressedResult = true;\n}\n\n//# sourceURL=webpack://installer/./src/client/js/calculator.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/client/js/calculator.js"]();
/******/ 	
/******/ })()
;