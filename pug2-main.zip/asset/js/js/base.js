/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client/js/base.js":
/*!*******************************!*\
  !*** ./src/client/js/base.js ***!
  \*******************************/
/***/ (() => {

eval("let n_click = document.getElementById(\"non_click\");\nn_click.addEventListener(\"mouseover\", event => {\n  event.target.style.color = \"aqua\";\n}, false);\nn_click.addEventListener(\"mouseout\", event => {\n  event.target.style.color = \"black\";\n}, false);\n\n//# sourceURL=webpack://installer/./src/client/js/base.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/client/js/base.js"]();
/******/ 	
/******/ })()
;