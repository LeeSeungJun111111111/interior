/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client/js/paint.js":
/*!********************************!*\
  !*** ./src/client/js/paint.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"circle\": () => (/* binding */ circle),\n/* harmony export */   \"floor\": () => (/* binding */ floor),\n/* harmony export */   \"img\": () => (/* binding */ img),\n/* harmony export */   \"square\": () => (/* binding */ square),\n/* harmony export */   \"straight\": () => (/* binding */ straight)\n/* harmony export */ });\n/* harmony import */ var _updatePaint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./updatePaint */ \"./src/client/js/updatePaint.js\");\n\nlet square = [];\nlet img = [];\nlet circle = [];\nlet straight = [];\nlet floor = [];\nlet paint;\nconst drawContainer = document.querySelector(\".drawingless\");\nconst paints = drawContainer.dataset.paints;\n\n// 사각형\n// 원\n// 직선\n// 이미지\n// 그리는 함수 제작\n\nfunction loadPaint() {\n  const paintArr = JSON.parse(paints);\n  paintArr.forEach(el => {\n    switch (el.name) {\n      case \"square\":\n        paint = new _updatePaint__WEBPACK_IMPORTED_MODULE_0__.squarePaint(el._id, el.sxPos, el.syPos, el.exPos, el.eyPos, el.color, el.border, el.name);\n        square.push(paint);\n        break;\n      case \"circle\":\n        paint = new _updatePaint__WEBPACK_IMPORTED_MODULE_0__.CirclePaint(el._id, el.sxPos, el.syPos, el.exPos, el.eyPos, el.color, el.border, el.name);\n        circle.push(paint);\n        break;\n      case \"straight\":\n        paint = new _updatePaint__WEBPACK_IMPORTED_MODULE_0__.StraightPaint(el._id, el.sxPos, el.syPos, el.exPos, el.eyPos, el.color, el.border, el.name);\n        straight.push(paint);\n        break;\n      case \"image\":\n        paint = new _updatePaint__WEBPACK_IMPORTED_MODULE_0__.imgPaint(el._id, el.sxPos, el.syPos, el.exPos, el.eyPos, el.color, el.name, el.list);\n        img.push(paint);\n        break;\n      case \"floor\":\n        paint = new _updatePaint__WEBPACK_IMPORTED_MODULE_0__.FloorPaint(el._id, el.sxPos, el.syPos, el.exPos, el.eyPos, el.color, el.border, el.name);\n        floor.push(paint);\n        break;\n    }\n  });\n}\nfunction init() {\n  if (paints) {\n    loadPaint();\n    console.log(square);\n  }\n}\ninit();\n\n//# sourceURL=webpack://installer/./src/client/js/paint.js?");

/***/ }),

/***/ "./src/client/js/updatePaint.js":
/*!**************************************!*\
  !*** ./src/client/js/updatePaint.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"CirclePaint\": () => (/* binding */ CirclePaint),\n/* harmony export */   \"FloorPaint\": () => (/* binding */ FloorPaint),\n/* harmony export */   \"StraightPaint\": () => (/* binding */ StraightPaint),\n/* harmony export */   \"imgPaint\": () => (/* binding */ imgPaint),\n/* harmony export */   \"squarePaint\": () => (/* binding */ squarePaint),\n/* harmony export */   \"updatePaint\": () => (/* binding */ updatePaint)\n/* harmony export */ });\nclass updatePaint {\n  constructor(_id, sx, sy, ex, ey, color) {\n    this.id = _id;\n    this.sx = sx;\n    this.sy = sy;\n    this.ex = ex;\n    this.ey = ey;\n    this.color = color;\n  }\n}\nclass squarePaint extends updatePaint {\n  constructor(_id, sx, sy, ex, ey, color, border, name) {\n    super(_id, sx, sy, ex, ey, color);\n    this.border = border;\n    this.name = name;\n  }\n}\nclass imgPaint extends updatePaint {\n  constructor(_id, sx, sy, ex, ey, name) {\n    super(_id, sx, sy, ex, ey, color);\n    this.name = name;\n    this.list = list;\n  }\n}\nclass CirclePaint extends updatePaint {\n  constructor(_id, sx, sy, ex, ey, color, border, name) {\n    super(_id, sx, sy, ex, ey, color);\n    this.border = border;\n    this.name = name;\n  }\n}\nclass StraightPaint extends updatePaint {\n  constructor(_id, sx, sy, ex, ey, color, border, name) {\n    super(_id, sx, sy, ex, ey, color);\n    this.border = border;\n    this.name = name;\n  }\n}\nclass FloorPaint extends updatePaint {\n  constructor(_id, sx, sy, ex, ey, color, border, name) {\n    super(_id, sx, sy, ex, ey, color);\n    this.border = border;\n    this.name = name;\n  }\n}\n\n//# sourceURL=webpack://installer/./src/client/js/updatePaint.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/client/js/paint.js");
/******/ 	
/******/ })()
;